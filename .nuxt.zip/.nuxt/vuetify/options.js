export default {"theme":{"dark":false}}
